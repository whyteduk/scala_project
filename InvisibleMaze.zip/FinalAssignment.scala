import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene.Scene
import scalafx.scene.control.{Alert, ButtonType, Label, Menu, MenuBar, MenuItem}
import scalafx.scene.input.{KeyCode, KeyEvent}
import scalafx.scene.layout.{Pane, StackPane, VBox}
import scalafx.scene.paint.Color
import scalafx.scene.shape.Rectangle
import scalafx.Includes._

object InvisibleMazeGame extends JFXApp {

  // To set the dimensions of the maze
  val mazeW = 5
  val mazeH = 5
  val tileSize = 40

  // This is to represent which rows in the grid can be accessed (true) or which cant (false)
  val maze: Array[Array[Boolean]] = Array(
    Array(true, false, false, false, false),
    Array(true, false, false, false, false),
    Array(true, true, false, false, false),
    Array(false, true, true, true, true),
    Array(false, false, false, false, true)
  )

  val finishX = mazeW - 1
  val finishY = mazeH - 1

  // Represents the player's position on the grid
  var playerX = 0
  var playerY = 0

  // This is the setting of the players
  val playerSize = 20
  val player = new Rectangle {
    width = playerSize
    height = playerSize
    fill = Color.Blue
  }

  val mazePane: Pane = new Pane {
    children = generateMazeNodes()
    children.add(player)
  }

  // This is a simple pane which provides basic tabs for the users to click on
  val root: StackPane = new StackPane {
    children = new VBox {
      children = Seq(
        new MenuBar {
          menus = Seq(
            new Menu("Info") {
              items = Seq(
                new MenuItem("Help") {
                  onAction = _ => showHelp()
                },
                new MenuItem("Exit") {
                  onAction = _ => System.exit(0)
                }
              )
            }
          )
        },
        new Label("Maze") {
          style = "-fx-font-size: 15;"
        },
        mazePane
      )
    }
  }

  stage = new PrimaryStage {
    title = "Simple Maze Game"
    scene = new Scene(root, mazeW * tileSize, mazeH * tileSize) {
      onKeyPressed = (event: KeyEvent) => handleKeyPress(event)
    }
  }

  // This represents each tile on the maze board.
  def generateMazeNodes(): Seq[Rectangle] = {
    for {
      row <- 0 until mazeH
      col <- 0 until mazeW
    } yield {
      val endTile = row == finishY && col == finishX
      val color = if (endTile) Color.Red else Color.Gray

      new Rectangle {
        x = col * tileSize
        y = row * tileSize
        width = tileSize
        height = tileSize
        fill = color
        stroke = Color.Black
      }
    }
  }

  def updatePlayerPosition(): Unit = {
    player.x = playerX * tileSize + (tileSize - playerSize) / 2
    player.y = playerY * tileSize + (tileSize - playerSize) / 2
  }

  // Used to detect keys pressed by the user
  def handleKeyPress(event: KeyEvent): Unit = {
    event.code match {
      case KeyCode.UP => playerMoves(0, -1)
      case KeyCode.DOWN => playerMoves(0, 1)
      case KeyCode.LEFT => playerMoves(-1, 0)
      case KeyCode.RIGHT => playerMoves(1, 0)
      case KeyCode.H => showHelp() // Press 'H' for help
      case _ =>
    }

    updatePlayerPosition() // Call updatePlayerPosition after processing key press

    // This is to show if they reached the end tile the completion message will pop up
    if (playerX == finishX && playerY == finishY) {
      showCompletionMessage()
    }
  }

  // This is to show change in direction on the row and col in the grid
  def playerMoves(xPos: Int, yPos: Int): Unit = {
    val newPlayerX = playerX + xPos
    val newPlayerY = playerY + yPos

    if (isMoveValid(newPlayerX, newPlayerY)) {
      playerX = newPlayerX
      playerY = newPlayerY
    }
  }

  // To see if the move is valid
  def isMoveValid(x: Int, y: Int): Boolean = {
    x >= 0 && x < mazeW && y >= 0 && y < mazeH && maze(y)(x)
  }

  // This is to pop up when they complete the maze
  def showCompletionMessage(): Unit = {
    val alert = new Alert(Alert.AlertType.Information) {
      title = "Congratulations!"
      headerText = "You completed the maze!"
      contentText = "Well done!"
    }
    alert.showAndWait()
    System.exit(0) // You might want to handle application termination more gracefully
  }

  // This is a simple prompt which will popup when pressed 'H'.
  def showHelp(): Unit = {
    val helpText =
      """
        How to play:
        | Get to the end of the maze which is highlighted in red,
        | You won't be able to see where you're going, so it's via trial and error.
        | Use arrow keys to move! Good Luck!
      """.stripMargin

    val alert = new Alert(Alert.AlertType.Information) {
      title = "Help"
      headerText = "The Invisible Maze"
      contentText = helpText
    }
    alert.showAndWait()
  }
}

